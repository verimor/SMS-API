<?php
$hook = array(
    'hook' => 'ClientAdd',
    'function' => 'ClientAdd',
    'hook_tr' => 'Yeni Müşteri',
    'title' => '',
    'description' => array(
        'turkish' => 'Müşteri kaydı tamamlandıktan sonra müşteriye mesaj gönderir',
        'english' => 'After Client Registration it sends a message to the client.'
    ),
    'type' => 'client',
    'extra' => '',
    'defaultmessage' => 'Sayin {firstname} {lastname}, Bizi tercih ettiginiz icin tesekkur ederiz. Email: {email} Sifre: {Girdiğiniz Sifre}',
    'variables' => '{firstname},{lastname},{email},{password}'
);

if (!function_exists('ClientAdd')) {
    function ClientAdd($args)
    {
        $service = new SmsService();

        $blocked = $service->isUserBlockedToSms($args['userid']);
        if ($blocked == "1") {
            return null;
        }

        $template = $service->getTemplateDetails(__FUNCTION__);
        if ($template == false) {
            return null;
        }
        $templateRow = $template->fetch(PDO::FETCH_ASSOC);
        if ($templateRow['active'] == 0) {
            return null;
        }
        $settings = $service->getSettings();
        $settingsRow = $settings->fetch(PDO::FETCH_ASSOC);
        if (!$settingsRow['usercode'] || !$settingsRow['password']) {
            return null;
        }
        $message = $templateRow['template'];
        $fields = $service->getFieldsWithName(__FUNCTION__);
        if (!empty($templateRow['smsfieldname'])) {

            $userSql = "SELECT c.*, v.value as `gsmnumber` FROM tblclients as c, tblcustomfieldsvalues as v 
			WHERE c.id='" . $args['userid'] . "' AND c.id=v.relid AND v.fieldid=(SELECT id FROM tblcustomfields WHERE fieldname='" . $templateRow['smsfieldname'] . "' AND type='client' AND fieldtype='text' LIMIT 1) LIMIT 1;";

            $stmt = $service->getConnection()->runSelectQuery($userSql);
            if ($stmt == false) {
                return null;
            }
            $clientRow = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($clientRow !== null) {
                if (empty($clientRow['gsmnumber'])) {
                    return null;
                }
                $gsm = $clientRow['gsmnumber'];
                if (strpos($message, "{password}") !== false) {
                    $message = str_replace("{password}", $args['password'], $message);
                }
                while ($field = $fields->fetch(PDO::FETCH_ASSOC)) {
                    if (strpos($message, "{" . $field['field'] . "}") !== false) {
                        $replaceto = $clientRow[$field['field']];
                        $message = str_replace("{" . $field['field'] . "}", $replaceto, $message);
                    }
                }
            }
        } else {

            if (strpos($message, "{password}") !== false) {
                $message = str_replace("{password}", $args['password'], $message);
            }

            while ($field = $fields->fetch(PDO::FETCH_ASSOC)) {
                if (strpos($message, "{" . $field['field'] . "}") !== false) {
                    $replaceto = $args[$field['field']];
                    $message = str_replace("{" . $field['field'] . "}", $replaceto, $message);
                }
            }

            $gsm = $args['phonenumber'];
        }

        $SMSArray = [];

        if ($gsm{0} === "+") {
            $gsm = substr($gsm, 3);
            $gsm = str_replace(".", "0", $gsm);
            $gsm = str_replace(" ", "", $gsm);

        } else if ($gsm{0} === "9") {
            $gsm = substr($gsm, 2);
            $gsm = str_replace(" ", "", $gsm);
        }
        if (ctype_digit($gsm)) {

            array_push($SMSArray, new SMS($message, $gsm));

            $request = new Request($templateRow['title'], $SMSArray, $settingsRow['usercode'], $settingsRow['password']);
            $request->prepareXMLRequest();
            $request->XMLPOST();
        }

    }
}

return $hook;